package com.opeanai.project.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.ai.azure.openai.AzureOpenAiChatOptions;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.ai.converter.ListOutputConverter;
import org.springframework.ai.converter.MapOutputConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.stereotype.Service;

import com.azure.ai.openai.OpenAIClientBuilder;
import com.opeanai.project.model.Player;

@Service
public class TextGenerationService {
	
	private final ChatClient  chatClient;

    public TextGenerationService(ChatClient.Builder chatClient) {
        this.chatClient = chatClient.build();
    }
    
    public List<String> findSportsPersonUsingListOutputConverter(String sports) {
		
		//wrap the message with the help of converter
		ListOutputConverter listOutputConverter = new ListOutputConverter(new DefaultConversionService()); //return List<String> only
		String format = listOutputConverter.getFormat(); //Think of this as an output schema or template that the AI should follow for easy deserialization.
		
		String template = """
	    		List of 5 popular personalities in {sports} and his details.
	    		{format}
	    		""";
	    PromptTemplate promptTemplate=new PromptTemplate(template);
	    Prompt prompt= promptTemplate.create(Map.of("sports",sports,"format",listOutputConverter.getFormat()));
	    ChatResponse response =  chatClient.prompt(prompt).call().chatResponse();
	    List<String> players_Details = listOutputConverter.convert(response.getResult().getOutput().getText());
	    return players_Details;
	}

	public Map<String, List<String>> findSportsPersonUsingBeanOutputConverter(String sports) {
		
		//The ParameterizedTypeReference<List<Player>> helps Jackson (or whatever JSON mapper) know the exact generic type because Java’s type erasure normally loses that info at runtime.
		BeanOutputConverter<List<Player>> outputConverter = new BeanOutputConverter<>(new ParameterizedTypeReference<List<Player>>() {});
		
		String format = outputConverter.getFormat(); //Think of this as an output schema or template that the AI should follow for easy deserialization.
		
		String template = """
	    		List of 5 popular personalities in {sports} and his details.
	    		{format}
	    		""";
	    PromptTemplate promptTemplate=new PromptTemplate(template);
	    Prompt prompt= promptTemplate.create(Map.of("sports",sports,"format",outputConverter.getFormat()));
	    ChatResponse response =  chatClient.prompt(prompt).call().chatResponse();
	    List<Player> players = outputConverter.convert(response.getResult().getOutput().getText());
	    System.out.println("List of players : "+players);
	    System.out.println("Mapped output in such a way that key will be players_name and value will be players_details : ");
	    Map<String, List<String>> players_details = players.stream().collect(Collectors.toMap(Player::Player_Name, Player::Player_Details));
	    return players_details;
	    
	}
	
	public Map<String, Object> findSportsPersonUsingMapOutputConverter(String sports) {
		
		//The ParameterizedTypeReference<List<Player>> helps Jackson (or whatever JSON mapper) know the exact generic type because Java’s type erasure normally loses that info at runtime.
		MapOutputConverter mapOutputConverter = new MapOutputConverter();
		
		String format = mapOutputConverter.getFormat(); //Think of this as an output schema or template that the AI should follow for easy deserialization.
		
		String template = """
	    		List of 5 popular personalities in {sports} and his details.
	    		{format}
	    		""";
	    PromptTemplate promptTemplate=new PromptTemplate(template);
	    Prompt prompt= promptTemplate.create(Map.of("sports",sports,"format",mapOutputConverter.getFormat()));
	    ChatResponse response =  chatClient.prompt(prompt).call().chatResponse();
	    Map<String, Object> players = mapOutputConverter.convert(response.getResult().getOutput().getText());
	    return players;
	    
	}
	
	public String findSportsPerson(String sports) {
		
		//In place of any random reply, if I want it should only respond to specific category, provide info to system
		
		var systemMessage = new SystemMessage("""
				Your primary function is to share the information about the sports personalities.
				If someone ask about anything else, you can only share about sports category.
				""");
		
		var userMessage = new UserMessage(
				String.format("List of 5 popular personalities in %s along\r\n"
						+ "	    		with their career achievements. ", sports));
		Prompt prompt=new Prompt(List.of(systemMessage,userMessage));
		ChatResponse response = chatClient.prompt(prompt).call().chatResponse();
		return response.getResult().getOutput().getText();
	}
	//API: "/getMessage/{message}"
	public String getChatCompletion(String message) {
        return chatClient.prompt(message).call().chatResponse().getResult().getOutput().getText();
    }
}

/*
 	Converter			Output type			Use case
	ListOutputConverter	List<String>		When OpenAI returns a list of strings (e.g., list of names)
	BeanOutputConverter	List<POJO> or POJO	When OpenAI returns structured JSON that maps to Java classes
	MapOutputConverter	Map<K,V>			When OpenAI returns JSON that you want as a key-value map instead of POJOs
 */