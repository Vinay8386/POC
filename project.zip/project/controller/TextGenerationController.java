package com.opeanai.project.controller;

import java.util.List;
import java.util.Map;

import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.opeanai.project.model.Player;
import com.opeanai.project.service.TextGenerationService;

@RestController
@RequestMapping("/api/openai")
public class TextGenerationController {
	
	@Autowired
	private TextGenerationService openAiService;

	@GetMapping("/getMessage/{message}")
	public ResponseEntity<String> getChatResponse(@PathVariable String message) {
	    String response = openAiService.getChatCompletion(message);
	    return ResponseEntity.ok(response);
	}
	
	@GetMapping("/{sports}")
	public Map<String, Object> findPopularSportsPerson(@PathVariable String sports) {
		return openAiService.findSportsPersonUsingMapOutputConverter(sports);
	}

}
