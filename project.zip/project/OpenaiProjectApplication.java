package com.opeanai.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenaiProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenaiProjectApplication.class, args);
	}

}
