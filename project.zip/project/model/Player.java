package com.opeanai.project.model;

import java.util.List;

public record Player(String Player_Name, List<String> Player_Details) {

}
