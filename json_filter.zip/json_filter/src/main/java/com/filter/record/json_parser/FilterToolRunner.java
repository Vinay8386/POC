package com.filter.record.json_parser;

import com.filter.record.json_parser.model.ACMRecord;
import com.filter.record.json_parser.service.FileProcessorUtil;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class FilterToolRunner implements CommandLineRunner {

    private final ApplicationContext applicationContext;

    // Constructor to inject ApplicationContext for graceful shutdown
    public FilterToolRunner(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void run(String... args) throws Exception {
        // Ensure at least 4 arguments are provided (inputFilePath, outputFilePath, filterField, filterValue)
    	
        if (args.length < 4) {
            System.out.println("❌ Invalid input.");
            System.out.println("✅ Usage: java -jar yourapp.jar <inputFilePath> <outputFilePath> <filterField> <filterValue>");
            return;
        }

        // Extract the command-line arguments
        String inputFilePath = args[0];       // Path to input file
        String outputFilePath = args[1];      // Path to output file (this is now configurable)
        String filterField = args[2];         // Field to filter by (e.g., BUENDEL_NUMMER)
        String filterValue = args[3];         // Filter value (e.g., 12345)
		/*
    	if (args.length < 6) {
    	    System.out.println("❌ Invalid input.");
    	    System.out.println("✅ Usage: java -jar yourapp.jar <inputFilePath> <outputFilePath> <filterField1> <filterValue1> <filterField2> <filterValue2>");
    	    return;
    	}

    	String inputFilePath = args[0];
    	String outputFilePath = args[1];
    	String filterField1 = args[2];
    	String filterValue1 = args[3];
    	String filterField2 = args[4];
    	String filterValue2 = args[5];
		*/
        // Create FileProcessorUtil and process the file
        FileProcessorUtil processor = new FileProcessorUtil();
        //processor.processFile(inputFilePath, filterField, filterValue, outputFilePath, ACMRecord.class);
        //processor.processFile(inputFilePath, filterField1, filterValue1, filterField2, filterValue2, outputFilePath, ACMRecord.class);
        processor.processFile(inputFilePath, filterField, filterValue, outputFilePath, ACMRecord.class);


        System.out.println("✔ Done: Records filtered and written to " + outputFilePath);

        // Gracefully shut down the Spring Boot application with exit code 0 (normal shutdown)
        SpringApplication.exit(applicationContext, () -> 0); // Exit code 0 indicates normal shutdown
    }
}

//java -jar json_parser-0.0.1-SNAPSHOT.jar C:\Users\vinamis\Desktop\source_code\acm-consume-message.json C:\Users\vinamis\Desktop\source_code\output_0111892-001.json "BUENDEL_NUMMER" "0111892-001"
