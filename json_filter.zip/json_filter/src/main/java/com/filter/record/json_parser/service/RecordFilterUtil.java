package com.filter.record.json_parser.service;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

// Responsible for filtering records based on any field and value.
public class RecordFilterUtil {

    // Generic method to filter records based on a field and its value
    public static <T> List<T> filterRecords(List<T> records, String fieldName, String fieldValue) {
        List<T> filteredRecords = new ArrayList<>();

        for (T record : records) {
            try {
                Field field = record.getClass().getDeclaredField(fieldName);
                field.setAccessible(true);

                // Get the field value and handle null safely
                Object fieldObject = field.get(record);
                String value = (fieldObject != null) ? fieldObject.toString() : null;

                // If the field value matches the provided filter value, add the record
                if (Objects.equals(value, fieldValue)) {
                    filteredRecords.add(record);
                }
            } catch (NoSuchFieldException | IllegalAccessException e) {
                // You could log the error here
                System.err.println("Error accessing field " + fieldName + " in class " + record.getClass().getName() + ": " + e.getMessage());
            }
        }
        return filteredRecords;
    }
	/*
	public static <T> List<T> filterRecords(List<T> records, Map<String, String> filters) {
	    List<T> filteredRecords = new ArrayList<>();

	    for (T record : records) {
	        boolean matches = true;
	        for (Map.Entry<String, String> entry : filters.entrySet()) {
	            try {
	                Field field = record.getClass().getDeclaredField(entry.getKey());
	                field.setAccessible(true);
	                Object value = field.get(record);
	                if (!Objects.equals(value != null ? value.toString() : null, entry.getValue())) {
	                    matches = false;
	                    break;
	                }
	            } catch (NoSuchFieldException | IllegalAccessException e) {
	                System.err.println("Error accessing field " + entry.getKey() + ": " + e.getMessage());
	                matches = false;
	                break;
	            }
	        }
	        if (matches) {
	            filteredRecords.add(record);
	        }
	    }

	    return filteredRecords;
	}*/
}
