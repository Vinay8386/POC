package com.filter.record.json_parser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonParserApplicationTests {

	@Test
	void contextLoads() {
	}

}
