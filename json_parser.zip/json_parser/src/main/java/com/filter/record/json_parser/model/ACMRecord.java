package com.filter.record.json_parser.model;

import java.util.Objects;

public class ACMRecord {
	private long ID;
    private String BUENDEL_NUMMER;
    private String VERANTWORTLICHER_FK;
    private long LASTDATACHANGE;
    private String BERECHNETER_PROZESS_STATUS;
    private String VORNAME;
    private String NAME;
    private String ABTEILUNG;
    private String MAIL;
    private String SACHNUMMER;
    private long SNR_ID;
    private String SNR_AENDERUNGSART;
    private long ERSETZTE_SACHNUMMER_FK;
    private String BAUREIHE;
    private String AUSFUEHRUNGSART;
    private String USAGE_AENDERUNGSART;
    private String AENDERUNGSBESCHREIBUNG;
    private String HAUPTMODUL;
    private String MODUL;
    private String SUBMODUL;
    private String POSITION;
    private String POSITIONSVARIANTE;
    private String BEZUGSART;
    private String REIFEGRAD;
    private String VERWENDUNGS_EINSCHRAENKUNG;
    private String QTY;
    private String AUSTAUSCHBAR;
    private String LENKUNG;
    private String USAGE_ID;
    private String PLANT;
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public String getBUENDEL_NUMMER() {
		return BUENDEL_NUMMER;
	}
	public void setBUENDEL_NUMMER(String bUENDEL_NUMMER) {
		BUENDEL_NUMMER = bUENDEL_NUMMER;
	}
	public String getVERANTWORTLICHER_FK() {
		return VERANTWORTLICHER_FK;
	}
	public void setVERANTWORTLICHER_FK(String vERANTWORTLICHER_FK) {
		VERANTWORTLICHER_FK = vERANTWORTLICHER_FK;
	}
	public long getLASTDATACHANGE() {
		return LASTDATACHANGE;
	}
	public void setLASTDATACHANGE(long lASTDATACHANGE) {
		LASTDATACHANGE = lASTDATACHANGE;
	}
	public String getBERECHNETER_PROZESS_STATUS() {
		return BERECHNETER_PROZESS_STATUS;
	}
	public void setBERECHNETER_PROZESS_STATUS(String bERECHNETER_PROZESS_STATUS) {
		BERECHNETER_PROZESS_STATUS = bERECHNETER_PROZESS_STATUS;
	}
	public String getVORNAME() {
		return VORNAME;
	}
	public void setVORNAME(String vORNAME) {
		VORNAME = vORNAME;
	}
	public String getNAME() {
		return NAME;
	}
	public void setNAME(String nAME) {
		NAME = nAME;
	}
	public String getABTEILUNG() {
		return ABTEILUNG;
	}
	public void setABTEILUNG(String aBTEILUNG) {
		ABTEILUNG = aBTEILUNG;
	}
	public String getMAIL() {
		return MAIL;
	}
	public void setMAIL(String mAIL) {
		MAIL = mAIL;
	}
	public String getSACHNUMMER() {
		return SACHNUMMER;
	}
	public void setSACHNUMMER(String sACHNUMMER) {
		SACHNUMMER = sACHNUMMER;
	}
	public long getSNR_ID() {
		return SNR_ID;
	}
	public void setSNR_ID(long sNR_ID) {
		SNR_ID = sNR_ID;
	}
	public String getSNR_AENDERUNGSART() {
		return SNR_AENDERUNGSART;
	}
	public void setSNR_AENDERUNGSART(String sNR_AENDERUNGSART) {
		SNR_AENDERUNGSART = sNR_AENDERUNGSART;
	}
	public long getERSETZTE_SACHNUMMER_FK() {
		return ERSETZTE_SACHNUMMER_FK;
	}
	public void setERSETZTE_SACHNUMMER_FK(long eRSETZTE_SACHNUMMER_FK) {
		ERSETZTE_SACHNUMMER_FK = eRSETZTE_SACHNUMMER_FK;
	}
	public String getBAUREIHE() {
		return BAUREIHE;
	}
	public void setBAUREIHE(String bAUREIHE) {
		BAUREIHE = bAUREIHE;
	}
	public String getAUSFUEHRUNGSART() {
		return AUSFUEHRUNGSART;
	}
	public void setAUSFUEHRUNGSART(String aUSFUEHRUNGSART) {
		AUSFUEHRUNGSART = aUSFUEHRUNGSART;
	}
	public String getUSAGE_AENDERUNGSART() {
		return USAGE_AENDERUNGSART;
	}
	public void setUSAGE_AENDERUNGSART(String uSAGE_AENDERUNGSART) {
		USAGE_AENDERUNGSART = uSAGE_AENDERUNGSART;
	}
	public String getAENDERUNGSBESCHREIBUNG() {
		return AENDERUNGSBESCHREIBUNG;
	}
	public void setAENDERUNGSBESCHREIBUNG(String aENDERUNGSBESCHREIBUNG) {
		AENDERUNGSBESCHREIBUNG = aENDERUNGSBESCHREIBUNG;
	}
	public String getHAUPTMODUL() {
		return HAUPTMODUL;
	}
	public void setHAUPTMODUL(String hAUPTMODUL) {
		HAUPTMODUL = hAUPTMODUL;
	}
	public String getMODUL() {
		return MODUL;
	}
	public void setMODUL(String mODUL) {
		MODUL = mODUL;
	}
	public String getSUBMODUL() {
		return SUBMODUL;
	}
	public void setSUBMODUL(String sUBMODUL) {
		SUBMODUL = sUBMODUL;
	}
	public String getPOSITION() {
		return POSITION;
	}
	public void setPOSITION(String pOSITION) {
		POSITION = pOSITION;
	}
	public String getPOSITIONSVARIANTE() {
		return POSITIONSVARIANTE;
	}
	public void setPOSITIONSVARIANTE(String pOSITIONSVARIANTE) {
		POSITIONSVARIANTE = pOSITIONSVARIANTE;
	}
	public String getBEZUGSART() {
		return BEZUGSART;
	}
	public void setBEZUGSART(String bEZUGSART) {
		BEZUGSART = bEZUGSART;
	}
	public String getREIFEGRAD() {
		return REIFEGRAD;
	}
	public void setREIFEGRAD(String rEIFEGRAD) {
		REIFEGRAD = rEIFEGRAD;
	}
	public String getVERWENDUNGS_EINSCHRAENKUNG() {
		return VERWENDUNGS_EINSCHRAENKUNG;
	}
	public void setVERWENDUNGS_EINSCHRAENKUNG(String vERWENDUNGS_EINSCHRAENKUNG) {
		VERWENDUNGS_EINSCHRAENKUNG = vERWENDUNGS_EINSCHRAENKUNG;
	}
	public String getQTY() {
		return QTY;
	}
	public void setQTY(String qTY) {
		QTY = qTY;
	}
	public String getAUSTAUSCHBAR() {
		return AUSTAUSCHBAR;
	}
	public void setAUSTAUSCHBAR(String aUSTAUSCHBAR) {
		AUSTAUSCHBAR = aUSTAUSCHBAR;
	}
	public String getLENKUNG() {
		return LENKUNG;
	}
	public void setLENKUNG(String lENKUNG) {
		LENKUNG = lENKUNG;
	}
	public String getUSAGE_ID() {
		return USAGE_ID;
	}
	public void setUSAGE_ID(String uSAGE_ID) {
		USAGE_ID = uSAGE_ID;
	}
	public String getPLANT() {
		return PLANT;
	}
	public void setPLANT(String pLANT) {
		PLANT = pLANT;
	}
	
	@Override
	public String toString() {
		return "ACMRecord [ID=" + ID + ", BUENDEL_NUMMER=" + BUENDEL_NUMMER + ", VERANTWORTLICHER_FK="
				+ VERANTWORTLICHER_FK + ", LASTDATACHANGE=" + LASTDATACHANGE + ", BERECHNETER_PROZESS_STATUS="
				+ BERECHNETER_PROZESS_STATUS + ", VORNAME=" + VORNAME + ", NAME=" + NAME + ", ABTEILUNG=" + ABTEILUNG
				+ ", MAIL=" + MAIL + ", SACHNUMMER=" + SACHNUMMER + ", SNR_ID=" + SNR_ID + ", SNR_AENDERUNGSART="
				+ SNR_AENDERUNGSART + ", ERSETZTE_SACHNUMMER_FK=" + ERSETZTE_SACHNUMMER_FK + ", BAUREIHE=" + BAUREIHE
				+ ", AUSFUEHRUNGSART=" + AUSFUEHRUNGSART + ", USAGE_AENDERUNGSART=" + USAGE_AENDERUNGSART
				+ ", AENDERUNGSBESCHREIBUNG=" + AENDERUNGSBESCHREIBUNG + ", HAUPTMODUL=" + HAUPTMODUL + ", MODUL="
				+ MODUL + ", SUBMODUL=" + SUBMODUL + ", POSITION=" + POSITION + ", POSITIONSVARIANTE="
				+ POSITIONSVARIANTE + ", BEZUGSART=" + BEZUGSART + ", REIFEGRAD=" + REIFEGRAD
				+ ", VERWENDUNGS_EINSCHRAENKUNG=" + VERWENDUNGS_EINSCHRAENKUNG + ", QTY=" + QTY + ", AUSTAUSCHBAR="
				+ AUSTAUSCHBAR + ", LENKUNG=" + LENKUNG + ", USAGE_ID=" + USAGE_ID + ", PLANT=" + PLANT + "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(ABTEILUNG, AENDERUNGSBESCHREIBUNG, AUSFUEHRUNGSART, AUSTAUSCHBAR, BAUREIHE,
				BERECHNETER_PROZESS_STATUS, BEZUGSART, BUENDEL_NUMMER, ERSETZTE_SACHNUMMER_FK, HAUPTMODUL, ID,
				LASTDATACHANGE, LENKUNG, MAIL, MODUL, NAME, PLANT, POSITION, POSITIONSVARIANTE, QTY, REIFEGRAD,
				SACHNUMMER, SNR_AENDERUNGSART, SNR_ID, SUBMODUL, USAGE_AENDERUNGSART, USAGE_ID, VERANTWORTLICHER_FK,
				VERWENDUNGS_EINSCHRAENKUNG, VORNAME);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ACMRecord other = (ACMRecord) obj;
		return Objects.equals(ABTEILUNG, other.ABTEILUNG)
				&& Objects.equals(AENDERUNGSBESCHREIBUNG, other.AENDERUNGSBESCHREIBUNG)
				&& Objects.equals(AUSFUEHRUNGSART, other.AUSFUEHRUNGSART)
				&& Objects.equals(AUSTAUSCHBAR, other.AUSTAUSCHBAR) && Objects.equals(BAUREIHE, other.BAUREIHE)
				&& Objects.equals(BERECHNETER_PROZESS_STATUS, other.BERECHNETER_PROZESS_STATUS)
				&& Objects.equals(BEZUGSART, other.BEZUGSART) && Objects.equals(BUENDEL_NUMMER, other.BUENDEL_NUMMER)
				&& ERSETZTE_SACHNUMMER_FK == other.ERSETZTE_SACHNUMMER_FK
				&& Objects.equals(HAUPTMODUL, other.HAUPTMODUL) && ID == other.ID
				&& LASTDATACHANGE == other.LASTDATACHANGE && Objects.equals(LENKUNG, other.LENKUNG)
				&& Objects.equals(MAIL, other.MAIL) && Objects.equals(MODUL, other.MODUL)
				&& Objects.equals(NAME, other.NAME) && Objects.equals(PLANT, other.PLANT)
				&& Objects.equals(POSITION, other.POSITION)
				&& Objects.equals(POSITIONSVARIANTE, other.POSITIONSVARIANTE) && Objects.equals(QTY, other.QTY)
				&& Objects.equals(REIFEGRAD, other.REIFEGRAD) && Objects.equals(SACHNUMMER, other.SACHNUMMER)
				&& Objects.equals(SNR_AENDERUNGSART, other.SNR_AENDERUNGSART) && SNR_ID == other.SNR_ID
				&& Objects.equals(SUBMODUL, other.SUBMODUL)
				&& Objects.equals(USAGE_AENDERUNGSART, other.USAGE_AENDERUNGSART)
				&& Objects.equals(USAGE_ID, other.USAGE_ID)
				&& Objects.equals(VERANTWORTLICHER_FK, other.VERANTWORTLICHER_FK)
				&& Objects.equals(VERWENDUNGS_EINSCHRAENKUNG, other.VERWENDUNGS_EINSCHRAENKUNG)
				&& Objects.equals(VORNAME, other.VORNAME);
	}    
}
