package com.filter.record.json_parser.service;

import com.google.gson.*;
import java.io.*;
import java.util.*;
import java.lang.reflect.Field;

public class FileProcessorUtil {

    private Gson gson = new Gson();  // Gson instance for serialization

    // Generic method to read records from a file and filter based on a field
    public <T> void processFile(String inputFilePath, String filterField1, String filterValue1, String filterField2, String filterValue2, String outputFilePath, Class<T> recordClass) throws IOException {
        List<T> filteredRecords = new ArrayList<>();

        // Use JsonReader for streaming input
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();

                if (line.isEmpty()) {
                    continue; // Skip empty lines
                }

                try {
                    // Deserialize each JSON object on the fly
                    T record = gson.fromJson(line, recordClass);

                    // Filter the record based on the given field and value
                   /* if (shouldIncludeRecord(record, filterField, filterValue)) {
                        filteredRecords.add(record);
                    }*/
                    if (shouldIncludeRecord(record, filterField1, filterValue1) &&
                    	   shouldIncludeRecord(record, filterField2, filterValue2)) {
                    	   filteredRecords.add(record);
                    }

                } catch (JsonSyntaxException e) {
                    System.out.println("Skipping invalid line: " + line);
                }
            }
        }

        // Write the filtered records to the output file
        writeRecordsToFile(filteredRecords, outputFilePath);
    }

    // Filter each record based on the specified field and value
    private <T> boolean shouldIncludeRecord(T record, String filterField, String filterValue) {
        try {
            Field field = record.getClass().getDeclaredField(filterField);
            field.setAccessible(true);
            String value = (field.get(record) != null) ? field.get(record).toString() : null;
            return value != null && value.equals(filterValue);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Write filtered records to output file
    private <T> void writeRecordsToFile(List<T> records, String outputFilePath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write("[\n");
            boolean firstRecord = true;
            for (T record : records) {
                if (!firstRecord) {
                    writer.write(",\n");
                }
                writer.write(gson.toJson(record));
                firstRecord = false;
            }
            writer.write("\n]");
        }
        System.out.println("Filtered records written to " + outputFilePath);
    }
}
