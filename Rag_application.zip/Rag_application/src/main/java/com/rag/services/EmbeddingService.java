package com.rag.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.ai.azure.openai.AzureOpenAiEmbeddingModel;
import org.springframework.ai.document.Document;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.annotation.PostConstruct;

@Service
public class EmbeddingService {
	
	//create a seperate service which will read all the file from input folder(src/main/resource/input/....) and create embedding in vector database
	//show the embedding in the form of .json inside the folder structure when application will start, so that I will understand it is working
	
	private final String inputFolder = "src/main/resources/input";
    private final String outputFolder = "src/main/resources/output";
    
    private final AzureOpenAiEmbeddingModel  embeddingModel; // Your Azure OpenAI client wrapper
    private final SimpleVectorStore vectorStore; // Your vector DB wrapper
    
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    public EmbeddingService(AzureOpenAiEmbeddingModel embeddingModel, SimpleVectorStore vectorStore) {
    	this.embeddingModel = embeddingModel;
        this.vectorStore = vectorStore;
    }
    
    /*
	     On startup (@PostConstruct), your service reads all files in src/main/resources/input.
		 For each file, creates an embedding using Azure OpenAI API.
		 Saves that embedding into the vector store.
		 Dumps embedding as a JSON file inside src/main/resources/output.
		 You can check output JSON files to verify the embeddings.
     */
    @PostConstruct 
    public void init() throws IOException {
        processFilesAndCreateEmbeddings();
    }
    
    private void processFilesAndCreateEmbeddings() throws IOException {
        Files.createDirectories(Paths.get(outputFolder)); // Ensure output directory exists

        Files.list(Paths.get(inputFolder))
            .filter(Files::isRegularFile)
            .forEach(filePath -> {
                try {
                    String content = Files.readString(filePath);

                    // Find first function start index (if any)
                    int firstFuncIndex = content.indexOf("def ");

                    String preamble = null;
                    List<String> functions = new ArrayList<>();

                    if (firstFuncIndex == -1) {
                        // No function definitions: entire content is preamble
                        preamble = content;
                    } else {
                        // Preamble is content before first function
                        preamble = content.substring(0, firstFuncIndex);

                        // Functions start from firstFuncIndex
                        String functionsPart = content.substring(firstFuncIndex);

                        // Split functions from functionsPart
                        functions = splitIntoFunctions(functionsPart);
                    }

                    // Prepare output file path
                    Path outputPath = Paths.get(outputFolder, filePath.getFileName().toString() + ".embedding.jsonl");

                    // Delete old output file if exists
                    if (Files.exists(outputPath)) {
                        Files.delete(outputPath);
                    }

                    // 1. Create embedding for preamble if it's not empty or just whitespace
                    if (preamble != null && !preamble.trim().isEmpty()) {
                        createAndSaveEmbedding(preamble, "preamble", filePath.getFileName().toString(), outputPath);
                    }

                    // 2. Create embeddings for each function
                    for (int i = 0; i < functions.size(); i++) {
                        String functionContent = functions.get(i);

                        String funcName = extractFunctionName(functionContent);
                        if (funcName == null || funcName.isEmpty()) {
                            funcName = "unknownFunc_" + i;
                        }

                        createAndSaveEmbedding(functionContent, funcName, filePath.getFileName().toString(), outputPath);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
    }

    private void createAndSaveEmbedding(String text, String name, String fileName, Path outputPath) {
        try {
            // Call embedding model
            EmbeddingResponse embeddingResponse = embeddingModel.call(
                new EmbeddingRequest(List.of(text), null)
            );

            float[] embeddingOutput = embeddingResponse.getResults().get(0).getOutput();

            // Create JSON object for this segment
            Map<String, Object> data = new HashMap<>();
            data.put("segmentName", name);
            data.put("text", text);
            data.put("embedding", embeddingOutput);

            // Append JSON line to output file
            saveEmbeddingLineAsJson(outputPath, data);

            // Add to vector store
            String docId = fileName + "_segment_" + name;
            Document doc = new Document.Builder()
                    .id(docId)
                    .text(text)
                    .metadata(Map.of("embedding", embeddingOutput))
                    .build();
            vectorStore.doAdd(List.of(doc));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    private void processFilesAndCreateEmbeddings() throws IOException {
        Files.createDirectories(Paths.get(outputFolder)); // Ensure output directory exists
        System.out.println("Input files:");
        Files.list(Paths.get(inputFolder))
            .filter(Files::isRegularFile)
            .forEach(filePath -> {
                try {
                    String content = Files.readString(filePath);

                    int firstFuncIndex = content.indexOf("def ");
                    if (firstFuncIndex != -1) {
                        content = content.substring(firstFuncIndex);
                    }

                    List<String> functions = splitIntoFunctions(content);

                    // Prepare output file path
                    Path outputPath = Paths.get(outputFolder, filePath.getFileName().toString() + ".embedding.jsonl");

                    // If output file exists from previous runs, delete it to start fresh
                    if (Files.exists(outputPath)) {
                        Files.delete(outputPath);
                    }

                    for (int i = 0; i < functions.size(); i++) {
                        String functionContent = functions.get(i);

                        String funcName = extractFunctionName(functionContent);
                        if (funcName == null || funcName.isEmpty()) {
                            funcName = "unknownFunc_" + i;
                        }

                        EmbeddingResponse embeddingResponse = embeddingModel.call(
                            new EmbeddingRequest(List.of(functionContent), null)
                        );

                        float[] embeddingOutput = embeddingResponse.getResults().get(0).getOutput();

                        // Create JSON object for this function
                        Map<String, Object> functionEmbeddingData = new HashMap<>();
                        functionEmbeddingData.put("functionName", funcName);
                        functionEmbeddingData.put("text", functionContent);
                        functionEmbeddingData.put("embedding", embeddingOutput);

                        // Save this single embedding as one JSON line in the output file
                        saveEmbeddingLineAsJson(outputPath, functionEmbeddingData);

                        // Add to vector store as before
                        String docId = filePath.getFileName().toString() + "_func_" + funcName;
                        Document doc = new Document.Builder()
                                .id(docId)
                                .text(functionContent)
                                .metadata(Map.of("embedding", embeddingOutput))
                                .build();
                        vectorStore.doAdd(List.of(doc));
                    }
                    System.out.println("==> Finished writing embeddings for: " + filePath.getFileName());

                } catch (Exception e) {
                    System.err.println("Error processing file: " + filePath.getFileName());
                    e.printStackTrace();
                }
            });
    }*/


    // Helper method: Extract function name from function string
    private String extractFunctionName(String functionContent) {
        Pattern namePattern = Pattern.compile("def\\s+(\\w+)\\s*\\(");
        Matcher matcher = namePattern.matcher(functionContent);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    // Helper method: Split content into functions with balanced braces
    private List<String> splitIntoFunctions(String content) {
        List<String> functions = new ArrayList<>();

        Pattern defPattern = Pattern.compile("def\\s+\\w+\\s*\\([^)]*\\)");
        Matcher matcher = defPattern.matcher(content);

        int searchStart = 0;
        while (matcher.find(searchStart)) {
            int funcStart = matcher.start();

            // Find the opening brace '{' after function signature
            int braceOpenIndex = content.indexOf('{', matcher.end());
            if (braceOpenIndex == -1) {
                // No function body found, skip this match
                searchStart = matcher.end();
                continue;
            }

            int braceCount = 1;
            int index = braceOpenIndex + 1;

            while (index < content.length() && braceCount > 0) {
                char c = content.charAt(index);
                if (c == '{') {
                    braceCount++;
                } else if (c == '}') {
                    braceCount--;
                }
                index++;
            }

            if (braceCount == 0) {
                String function = content.substring(funcStart, index);
                functions.add(function);
                searchStart = index;
            } else {
                // Unbalanced braces - stop to avoid infinite loop
                break;
            }
        }

        return functions;
    }
    
    private void saveEmbeddingLineAsJson(Path outputPath, Map<String, Object> functionEmbeddingData) {
        try {
            // Convert map to JSON string
            String jsonLine = objectMapper.writeValueAsString(functionEmbeddingData);

            // Write JSON line + newline, append mode
            Files.writeString(outputPath, jsonLine + System.lineSeparator(), 
                java.nio.file.StandardOpenOption.CREATE, 
                java.nio.file.StandardOpenOption.APPEND);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /*
	private void processFilesAndCreateEmbeddings() throws IOException {
		
		Files.createDirectories(Paths.get(outputFolder)); // Ensure output directory exists
		
		Files.list(Paths.get(inputFolder))
				.filter(Files::isRegularFile)
				.forEach(filePath -> {
					try {
						String content = Files.readString(filePath);
						
						// Create the embedding using Spring AI
						EmbeddingResponse embeddingResponse = embeddingModel.call(new EmbeddingRequest(List.of(content),null)); //The second argument options is optional configuration or parameters for the embedding request.
						//Typically, EmbeddingOptions can include things like embedding model or Specific parameters like maxTokens, temperature, or other provider-specific tuning options
						
						float[] embeddingOutput = embeddingResponse.getResults().get(0).getOutput();
						
						// Store embedding vector in metadata
			            Map<String, Object> metadata = Map.of("embedding", embeddingOutput);
						
						 // Create Spring AI Document with id and embedding (no content)
						Document doc = new Document.Builder()
				                .id(filePath.getFileName().toString())
				                .text(content) // Needed if using vector store’s embedding mechanism
				                .metadata(metadata)
				                .build();
						
						// Add Document to vector store
						vectorStore.doAdd(List.of(doc));
						
						// Save embedding as JSON for verification
						saveEmbeddingAsJson(filePath.getFileName().toString(),content, embeddingOutput);
						
					} catch (Exception e) {
	                    e.printStackTrace();
	                }
				});
	}

	private void saveEmbeddingAsJson(String fileName,String content, float[] embeddingOutput) {
		
		try {
	        Path outputPath = Paths.get(outputFolder, fileName + ".embedding.json");
	        
	        Map<String, Object> jsonMap = new HashMap<>();
	        jsonMap.put("text", content);
	        jsonMap.put("embedding", embeddingOutput);

	        objectMapper.writeValue(outputPath.toFile(), jsonMap);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}*/
}

/**
 * EmbeddingService
 *
 * On application startup, this service reads all text files from the input folder (src/main/resources/input),
 * generates vector embeddings for each file's content using the Azure OpenAI embedding model,
 * and stores these embeddings in a vector database.
 *
 * Additionally, for verification and debugging purposes, it saves each embedding along with the original text
 * as a JSON file in the output folder (src/main/resources/output) in the following format:
 * {
 *   "text": "<original file content>",
 *   "embedding": [<embedding vector as float array>]
 * }
 *
 * This helps ensure embeddings are correctly generated and stored,
 * and provides an easy way to inspect the processed data.
 */
