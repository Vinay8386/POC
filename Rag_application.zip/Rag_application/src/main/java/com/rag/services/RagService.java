package com.rag.services;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import org.springframework.ai.azure.openai.AzureOpenAiEmbeddingModel;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.SystemPromptTemplate;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.stereotype.Service;

@Service
public class RagService {
	
	
	private final SimpleVectorStore vectorStore;
    private final ChatClient chatClient;
    
    public RagService(SimpleVectorStore vectorStore, AzureOpenAiEmbeddingModel embeddingModel,ChatClient chatClient) {
        this.vectorStore = vectorStore;
		this.chatClient = chatClient;
    }
    
    //Searches for relevant documents in the vector store based on the query.
    public List<Document> searchRelevantDocs(String prompt) {
    	SearchRequest request = SearchRequest.builder()
                .query(prompt)
                .topK(5)                      // get top 5 results
                .similarityThreshold(0.75)    // filter by similarity score
                .build();
    	
    	List<Document> searchDocument = vectorStore.doSimilaritySearch(request);
    	
    	System.out.println("Searched relevent document is : "+searchDocument);
    	
        return searchDocument;
    }
    
    
    //Generates response by combining prompt, query, and enhanced context from vector store. Returns error message if no relevant documents found. 
    public String generateEnhancedResponse(String prompt) throws Exception {
        List<Document> relevantDocs = searchRelevantDocs(prompt);

        if (relevantDocs.isEmpty()) {
            return "No relevant information found in the vector database for your query.";
        }

        StringBuilder enhancedContext = new StringBuilder();
        for (Document doc : relevantDocs) {
            enhancedContext.append(doc.getText()).append("\n");
        }

        String finalPrompt = prompt + "\n\nContext:\n" + enhancedContext.toString();
        
        // Decide which rulebook to use based on query intent
        String ruleDocToUse;
        if (isFullExplanationRequest(prompt)) {
            ruleDocToUse = "src/main/resources/rule_full_explanation.txt";
        } else if (isCodeGenerationRequest(prompt)) {
            ruleDocToUse = "src/main/resources/rule_code_generation.txt";
        } else {
            ruleDocToUse = "src/main/resources/rule_actual_implementation.txt";
        }

        return getFinalResponse(finalPrompt, ruleDocToUse);
    }
    
    private boolean isCodeGenerationRequest(String prompt) {
        String q = prompt.toLowerCase();
        // Simple keyword check to decide if user wants sample/pseudocode generation
        return q.contains("sample code") || 
               q.contains("example") || 
               q.contains("pseudocode") || 
               q.contains("generate") || 
               q.contains("show me code");
    }
    
    private boolean isFullExplanationRequest(String prompt) {
        String q = prompt.toLowerCase();
        return q.contains("details") || q.contains("explain") || q.contains("description") || q.contains("how does");
    }
    
    //Call the Azure OpenAI model to generate a response for the given prompt.
    private String getFinalResponse(String finalPrompt, String ruleDocPath) throws Exception {
        
    	// Load rule doc content from file
        String ruleDocContent = Files.readString(Path.of(ruleDocPath), StandardCharsets.UTF_8);
    	
        // System prompt template with placeholders
        String systemText = """
            You are a helpful assistant.

            Follow these instructions carefully before answering:
            {rules}

            Use the following information to answer the question:
            {information}
            """;
       
        
        // Create system message using SystemPromptTemplate
        SystemPromptTemplate systemPromptTemplate = new SystemPromptTemplate(systemText);
        Message systemMessage = systemPromptTemplate.createMessage(
                Map.of("rules", ruleDocContent, "information", finalPrompt)  // <-- This map must contain 'information'
            );

        // Create user message
        Message userMessage = new UserMessage(String.format("Please answer the query: \\\"%s\\\". Write ONLY Modscript code (no Python, no pseudocode unless instructed). Label code blocks as 'Modscript'.",finalPrompt));

        // Prepare messages list in order: system message first, then user message
        List<Message> messages = List.of(systemMessage, userMessage);

        // Create prompt from messages
        Prompt prompt = new Prompt(messages);

        // Call the chat client and get the response content as string
        var response = chatClient.prompt(prompt).call().content();

        return response;
    }
}
