package com.rag.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rag.services.RagService;

@RestController
public class RagController {
	
	private final RagService ragService;

    public RagController(RagService ragService) {
        this.ragService = ragService;
    }
    
    @GetMapping("/chat")
    public String chat(
            @RequestParam String prompt) {

    	String response = null;
		try {
			response = ragService.generateEnhancedResponse(prompt);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	return response;
    }
}